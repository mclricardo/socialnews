socialnews
==========

socialnews = knockoutjs + signalr